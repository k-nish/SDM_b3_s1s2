Data = xlsread('11.xls','加入者','B13:E33');

disp(Data)

%2005年を過去、
%end=360,t=240,

for i=150:240
	a_i = Data(3:1,)
endfor


